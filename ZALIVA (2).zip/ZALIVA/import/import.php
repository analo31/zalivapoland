<?php

exec('node assets/js/script.js && 7z x -o../ tmp/'. $_SERVER["SERVER_NAME"]. '.zip -aoa', $output, $return_var);
if (!empty($output)) {
    echo $output[0];
} else {
    echo json_encode(['error' => 'Произошла ошибка']);
}