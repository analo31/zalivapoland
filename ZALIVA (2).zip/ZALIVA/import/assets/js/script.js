const puppeteer = require('puppeteer');
const fs = require('fs');

class SiteUpdate {
    constructor() {
        this.browser = null;
        this.page = null;
        this.client = null;
        this.submitButtonSelector = 'button[type=submit]';
        this.configBlockSelector = 'textarea[name=config_json]';
        this.configPath = '../config.json';
        this.configBlock = null;
        this.config = null;
        this.site = 'https://ein.gg/oowg/';
        this.domainName = '';
        this.archiveFolder = 'tmp';

        this.init();
    }
    async init() {
        try {
            await this.setBrowser();
            await this.setPage();
            await this.setClient();
            await this.setDownloadAllow();
            await this.loadPage();

            const download = this.setDownloadListener();

            await this.findConfigBlock();

            if (!this.configBlock) {
                await this.setExperementalMode();
                await this.findConfigBlock();
            }

            if (this.configBlock) {
                this.getConfigFromFile();
                await this.fillConfigBlock();
                await new Promise((resolve) => {
                    setTimeout(() => {
                        resolve(this.downloadArchive());
                    }, 30000);
                });
                await download;
            } else {
                throw 'Конфиг-блок не найден';
            }
        } catch (e) {
            this.closeBrowser();
            this.removeBackup();
            console.log(JSON.stringify({
                error: [e.message]
            }));
        }
    }
    async setBrowser() {
        try {
            this.browser = await puppeteer.launch({
                product: 'chrome',
                args: ['--no-sandbox']
            });
        } catch(e) {
            throw new Error(`Произошла ошибка при открытии браузера: ${e}`);
        }

    }
    async setPage() {
        try {
            this.page = await this.browser.newPage();
        } catch(e) {
            throw new Error(`Произошла ошибка при переходе на сайт: ${e}`);
        }

    }
    async setClient() {
        try {
            this.client = await this.page.target().createCDPSession();
        } catch(e) {
            throw new Error(`Произошла ошибка при открытии браузера: ${e}`);
        }
    }
    async setDownloadAllow() {
        try {
            await this.client.send('Browser.setDownloadBehavior', {
                behavior: 'allow',
                downloadPath: this.archiveFolder,
                eventsEnabled: true
            });
        } catch(e) {
            throw new Error(`Произошла ошибка при установке разрешение на скачивание: ${e}`);
        }
    }
    async loadPage() {
        try {
            await this.page.goto(this.site, { waitUntil: 'load' });
            await this.page.waitForSelector(this.submitButtonSelector);
        } catch(e) {
            throw new Error(`Произошла ошибка при загрузке страницы: ${e}`);
        }
    }
    async findConfigBlock() {
        try {
            this.configBlock = await this.page.$(this.configBlockSelector);
        } catch(e) {
            throw new Error(`Конфиг-блок не найден: ${e}`);
        }
    }
    async setExperementalMode() {
        try {
            const [experimentalModeBtn] = await this.page.$x("//p[contains(text(), 'Experimental Mode')]");
            if (experimentalModeBtn) {
                await experimentalModeBtn.click();
            } else {
                throw 'Блок не найден';
            }
        } catch(e) {
            throw new Error(`Произошла ошибка при поиске Experimental Mode: ${e}`);
        }
    }
    getConfigFromFile() {
        try {
            this.config = fs.readFileSync(this.configPath, 'utf8');
            if (!this.config) {
                throw 'Файл пуст';
            }
        } catch(e) {
            throw new Error(`Произошла ошибка при открытии файла config.json: ${e}`);
        }

    }
    async fillConfigBlock() {
        try {
            await this.page.$eval(
                this.configBlockSelector,
                (el, conf) => el.value = conf,
                this.config
            );
            await this.page.type(this.configBlockSelector, ' ');
        } catch(e) {
            throw new Error(`Произошла ошибка при вставке конфига: ${e}`);
        }
    }
    async downloadArchive() {
        try {
            await this.page.click(this.submitButtonSelector);
        } catch(e) {
            throw new Error(`Произошла ошибка при скачивании архива: ${e}`);
        }
    }
    async setDownloadListener () {
        return new Promise((resolve, reject) => {
            this.client.on('Browser.downloadProgress', async (event) => {
                try {
                    if (event.state == 'completed' ) {
                        await this.closeBrowser();
                        resolve(console.log(JSON.stringify({
                            success: "Готово"
                        })));
                    } else if (event.state === 'canceled') {
                        throw new Error(event.state);
                    }
                } catch(e) {
                    reject(new Error(`Произошла ошибка при скачивании архива: ${e}`));
                }
            });
        })
    }
    async closeBrowser() {
        await this.browser.close();
    }
}


const update = new SiteUpdate();