<?php
exec('export PUPPETEER_SKIP_DOWNLOAD=true');
exec('export PUPPETEER_SKIP_CHROMIUM_DOWNLOAD=true');
exec('npm i 2>&1', $output);
exec('node node_modules/puppeteer/install.js  2>&1', $output);

// if (!empty($output)) {
//     var_dump($output);
// }

echo 'Готово';